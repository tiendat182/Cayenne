package org.example.cayenne.persistent;

import org.example.cayenne.persistent.auto._Gallery;

public class Gallery extends _Gallery {

    private static final long serialVersionUID = 1L; 

}
