package org.example.cayenne;

import org.apache.cayenne.ObjectContext;
import org.apache.cayenne.configuration.server.ServerRuntime;
import org.example.cayenne.persistent.Artist;
import org.example.cayenne.persistent.Gallery;
import org.example.cayenne.persistent.Painting;

/**
 * Getting started with ObjectContext
 * 
 * @author DatLT
 *
 */
public class Main {

	public static void main(String[] args) {
		ServerRuntime cayenneRuntime = new ServerRuntime("cayenne-project.xml");
		ObjectContext context = cayenneRuntime.getContext();

		Artist picasso = context.newObject(Artist.class);
		picasso.setName("Pablo Picasso");
		picasso.setDateOfBirthString("18021988");

		Gallery metropolitan = context.newObject(Gallery.class);
		metropolitan.setName("Metropolitan Museum of Art");

		Painting girl = context.newObject(Painting.class);
		girl.setName("Girl Reading at a Table");

		Painting stein = context.newObject(Painting.class);
		stein.setName("Gertrude Stein");

		picasso.addToPaintings(girl);
		picasso.addToPaintings(stein);
		girl.setGallery(metropolitan);
		stein.setGallery(metropolitan);

		context.commitChanges();
	}

}
