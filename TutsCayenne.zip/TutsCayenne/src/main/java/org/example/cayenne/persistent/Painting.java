package org.example.cayenne.persistent;

import org.example.cayenne.persistent.auto._Painting;

public class Painting extends _Painting {

    private static final long serialVersionUID = 1L; 

}
